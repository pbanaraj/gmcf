jQuery(document).ready(function(){
	$('.loader_testimonial').show();
	$('.loader_products').show();
	setTimeout(function() {
		$('.loader_testimonial').hide();
		$('.loader_products').hide();
		jQuery('.bxslider-social').show().bxSlider({
					minSlides : 1,
					maxSlides : 1,
					slideWidth : 600,
					slideMargin : 10,
					auto: true,
		});
			
		jQuery('.bxslider').show().bxSlider({
							minSlides : 1,
							maxSlides : 3,
							slideWidth : 400,
							slideMargin : 10,
							infiniteLoop: false,
							hideControlOnEnd: true
		});
		//Accordian
		jQuery('.accordion').each(function () {
						var accordian = jQuery(this);
						accordian.find('.accordion-head').on('click', function () {
							jQuery(this).parent().find(".accordion-head").removeClass('open close1');
							jQuery(this).removeClass('open').addClass('close1');
							accordian.find('.accordion-body').slideUp();
							if (!jQuery(this).next().is(':visible')) {
								jQuery(this).removeClass('close1').addClass('open');
								jQuery(this).next().slideDown();
							}
						});
		});
	},2000);
});