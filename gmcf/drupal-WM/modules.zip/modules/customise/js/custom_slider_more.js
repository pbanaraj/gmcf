(function ($) {   
   $(document).ready(function() {


				$('.cascade-slider_nav li:gt(4)').hide();

				$('.prev').click(function() {
					var first = $('.cascade-slider_nav').children('li:visible:first');
					first.prevAll(':lt(5)').css("display", "inline-block");
					first.prev().nextAll().hide()
				});

				$('.next').click(function() {
					var last = $('.cascade-slider_nav').children('li:visible:last');
					last.nextAll(':lt(5)').css("display", "inline-block");
					last.next().prevAll().hide();
				});





				$('#cascade-slider').cascadeSlider({
			
			});
			});
})(jQuery);
