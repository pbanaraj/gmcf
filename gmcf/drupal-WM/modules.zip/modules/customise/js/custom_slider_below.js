(function ($) {   
   'use strict';
   $(document).ready(function() {
				$('#cascade-slider').cascadeSlider({
			
			});
			});
   
})(jQuery);
