(function ($) {   
   'use strict';
   $(document).on('change','.sortRates',function(e){
	 var key_val = $(this).val();
     var rates = JSON.parse($("#rates_data").val());
	 switch(key_val) {
		case 'LMP':
					rates.sort(function(a, b) {
						return parseFloat(a.MonthlyPayment) - parseFloat(b.MonthlyPayment);
					});
					break;
		case 'LR':
					rates.sort(function(a, b) {
						return parseFloat(a.Rate) - parseFloat(b.Rate);
					});
					break;
		case 'LF':
					rates.sort(function(a, b) {
						return parseFloat(a.TotalFees) - parseFloat(b.TotalFees);
					});
					break;
	 }
	 	
	 $.post("/quick_rate_sort",{  "rates": rates,'type_sort': key_val},function(data) {
			$('#quick_rate_result').html(data);
			jQuery('.accordion').each(function () {
						var accordian = jQuery(this);
						accordian.find('.accordion-head').on('click', function () {
							jQuery(this).parent().find(".accordion-head").removeClass('open close1');
							jQuery(this).removeClass('open').addClass('close1');
							accordian.find('.accordion-body').slideUp();
							if (!jQuery(this).next().is(':visible')) {
								jQuery(this).removeClass('close1').addClass('open');
								jQuery(this).next().slideDown();
							}
			});
			jQuery('[data-toggle="tooltip"]').tooltip();
		});
	 });
   });

			 $.validator.addMethod('qrq_lessThan', function(value, element, param) {
				var i = parseInt(value);
				var j = parseInt($(param).val());
				return i < j;
			}, "Less Than");
			$.validator.addMethod('qrq_greaterThan', function(value, element) {
				var i = parseInt(value);
				return i > 0;
			}, "Greater Than");
			
			$.validator.addMethod('checkZipCode', function (value, element){
                  
              
              var return_val = false;
			  if(value.length == 5) {
				  $.ajax({
					  url: 'https://fgmc.common.local:5100/api/v1/state/'+value,
					  type: 'GET',
					  dataType:"json",                  
					  async: false,
					  success : function(response) {					  
								if(response.length > 0){
								  return_val = false;
							   }
							   else{
								   return_val = true;
							   }
							}
					  });
				}
                  return return_val;
            });
			$.validator.addMethod('checkZipCodeService', function (value, element){
                  
              
              var return_val = false;
			  if(value.length == 5) {
				  $.ajax({
					  url: 'https://fgmc.common.local:5100/api/v1.0/State/'+value+'/serviced',
					  type: 'GET',
					  dataType:"json",                  
					  async: false,
					  success : function(response) {
							   if(response){
								  return_val = true;
							   }
							   else{
								   return_val = false;
							   }
							}
					  });
				}
                  return return_val;
            });
			
	            $('#quick_rate_form').validate({
	               errorElement: "div",
	               errorClass: "error",
	               rules: {	                  
	                   "qrq_purchase_price": {required : true,number:true,qrq_greaterThan:true},
	                   "qrq_down_payment": {required : true,number:true,qrq_greaterThan:true,
							qrq_lessThan: '#qrq_purchase_price'},
	                   "qrq_zipcode": {
	                       required: true,number:true,qrq_greaterThan:true,
						   checkZipCode:true,
						   checkZipCodeService:true,
	                       minlength:5						   
	                   },
					   "qrq_credit_score": {required: true},
					   "qrq_loan_product[]": {required: true},
					   "qrq_customer_name": {required: true},
	                   "qrq_customer_phone": {required: true},
					   "qrq_customer_email": {required: true,email:true}
	
	               },
	               messages: {
					   "qrq_purchase_price": {required : "Please enter the purchase price of the property you would like to purchase.",qrq_greaterThan:"Please enter the purchase price greater than zero."},
	                   "qrq_down_payment": {required : "Please enter the down payment amount.",qrq_greaterThan:"Please enter the down payment greater than zero.",
							qrq_lessThan: "The down payment amount cannot be equal to or more than the purchase price."},
	                   "qrq_zipcode": {
	                       required: "Please enter zip code",qrq_greaterThan:"Please enter the zip code greater than zero.",
						   checkZipCode:"Please enter a valid zipcode.",
						   checkZipCodeService:"Sorry, the location entered by you is currently not serviced by us. We will be there soon.",
	                       minimum:"Please enter a valid zip code."
	                   },
					   "qrq_credit_score": {required: "Please select your credit score range."},
					   "qrq_loan_product[]": {required: "Please select your loan product."},
					   "qrq_customer_name": {required: "Please enter your name."},
	                   "qrq_customer_phone": {required: "Please enter your phone number."},
					   "qrq_customer_email": {required: "Please enter your email.",email:"Please enter a valid email address."} 
	               },
	               submitHandler: function(form) {  
                           if ($(form).valid()) 
                               form.submit(); 
                           return false; // prevent normal form posting
                    }
	           });
			   	 $('#quick_rate_ref_form').validate({
	               errorElement: "div",
	               errorClass: "error",
	               rules: {	                  
	                   "qrq_home_value": {required : true,number:true,qrq_greaterThan:true},
	                   "qrq_current_balance": {required : true,number:true,qrq_greaterThan:true,
							qrq_lessThan: '#qrq_home_value'},
	                   "qrq_zipcode": {
	                       required: true,number:true,qrq_greaterThan:true,
						   checkZipCode:true,
						   checkZipCodeService:true,
	                       minlength:5	                      
	                   },
					   "qrq_credit_score": {required: true},
					   "qrq_loan_product[]": {required: true},
					   "qrq_customer_name": {required: true},
	                   "qrq_customer_phone": {required: true},
					   "qrq_customer_email": {required: true,email:true}
	
	               },
	               messages: {
					   "qrq_home_value": {required : "Please enter the estimated property value.",qrq_greaterThan:"Please enter the home value greater than zero."},
	                   "qrq_current_balance": {required : "Please enter your current mortgage balance.",qrq_greaterThan:"Please enter the current balance greater than zero.",
							qrq_lessThan: "Current balance must be less than Home Value."},
	                   "qrq_zipcode": {
	                       required: "Please enter zip code",qrq_greaterThan:"Please enter the zip code greater than zero.",
						   checkZipCode:"Please enter a valid zipcode.",
						   checkZipCodeService:"Sorry, the location entered by you is currently not serviced by us. We will be there soon.",
	                       minimum:"Please enter a valid zip code."	                      
	                   },
					   "qrq_credit_score": {required: "Please select your credit score range."},
					   "qrq_loan_product[]": {required: "Please select your loan product."},
					   "qrq_customer_name": {required: "Please enter your name."},
	                   "qrq_customer_phone": {required: "Please enter your phone number."},
					   "qrq_customer_email": {required: "Please enter your email",email:"Please enter a valid email address"} 
	               },
	              submitHandler: function(form) {  
                           if ($(form).valid()) 
                               form.submit(); 
                           return false; // prevent normal form posting
                    } 
	           });

			   $("#qrq_customer_phone").mask("(999) 99?9-9999",{placeholder:" "});

				$("#qrq_customer_phone").on("blur", function() {
					var last = $(this).val().substr( $(this).val().indexOf("-") + 1 );
					
					if( last.length == 3 ) {
						var move = $(this).val().substr( $(this).val().indexOf("-") - 1, 1 );
						var lastfour = move + last;
						
						var first = $(this).val().substr( 0, 9 );
						
						$(this).val( first + '-' + lastfour );
					}
				});
				$("#qrq_customer_phone_ref").mask("(999) 99?9-9999",{placeholder:" "});


				$("#qrq_customer_phone_ref").on("blur", function() {
					var last = $(this).val().substr( $(this).val().indexOf("-") + 1 );
					
					if( last.length == 3 ) {
						var move = $(this).val().substr( $(this).val().indexOf("-") - 1, 1 );
						var lastfour = move + last;
						
						var first = $(this).val().substr( 0, 9 );
						
						$(this).val( first + '-' + lastfour );
					}
				});		
				$('.select_loan_products').multiselect({
					nonSelectedText:"Loan Product",
					includeSelectAllOption: true,
					selectAllText: 'Unsure',
				});
				if($("#loan_products_arr").val()) {
					var loan_product_json = JSON.parse($("#loan_products_arr").val()); 
					$("#qrq_submit .select_loan_products").multiselect('select',loan_product_json);
				}
})(jQuery);

function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
function onlyAlphabets(e) {
                if (window.event) {
                    var charCode = window.event.keyCode;
                }
                else if (e) {
                    var charCode = e.which;
                }
                else { return true; }
                if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 39 || charCode == 45 || charCode == 8 || charCode == 127 )
                    return true;
                else
                    return false;
} 
