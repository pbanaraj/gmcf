<?php
namespace Drupal\customise\Controller;

use \Drupal\Core\Url;
use Drupal\customise\Form\ContributeForm;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax;
use Drupal\Core\Ajax\CssCommand;

/**
 * key Content Type Controller.
 */
class CustomiseController extends ControllerBase {

  /**
   * Initializing the things here.
   */
  /*public function __construct() {
    global $base_url;
    $this->storage = \Drupal::entityTypeManager()->getStorage("node");
    $this->user_storage = \Drupal::entityTypeManager()->getStorage("user");
    $this->current_user = \Drupal::currentUser();
    $this->current_user_uid = \Drupal::currentUser()->id();
    $this->base_url = $base_url;
  } */
  public function product_details($arg =  null){
	
	$pd_config 	= \Drupal::config('demo.settings')->get('pd_config');
	$page_title =  $pd_config['pd_title']; 
	$page_desc 	=  $pd_config['pd_desc']; 
	$finalResult = array();
	$sid = 'homepage_product';
	$entity_subqueue = \Drupal::entityManager()->getStorage('entity_subqueue')->load($sid);
	$items = $entity_subqueue->get('items')->getValue();
	foreach($items as $item) {
		$nodeids[] = $item['target_id'];
	}
	$nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeids);
	$i= 1;
	$center = 0;	
	foreach($nodes as $node) {
	  $nid = $node->get('nid')->value;
	  if($nid == $arg)
		  $center = $i;
	  $product_image = $node->get('field_image')->entity->uri->value;
	  
	  if($product_image && $product_image != '')
			$finalResult[$i]['product_image'] 		= file_create_url($node->get('field_image')->entity->uri->value);
	  else{
		  
		  $finalResult[$i]['product_image'] = '';
	  }
		  
	  $finalResult[$i]['title'] 				= $node->get('title')->value; 	 	  
	  $finalResult[$i]['product_short_desc'] 	= $node->get('field_product_short_desc')->value;
	  $finalResult[$i]['product_long_desc'] 	= $node->get('field_product_long_desc')->value;	  
	  $finalResult[$i]['product_video_url'] 	= $node->get('field_product_video_url')->value;
	  $finalResult[$i]['product_dyk'] 			= $node->get('field_product_section_desc')->value;
	  $finalResult[$i]['product_vowel'] 		= $this->product_vowel_chk($finalResult[$i]['title']);
	  $i++;
	  
	}
	$count  = count($finalResult);
	$is_mobile = $this->isMobileDev();
	if($center){
		if($count <= 7)
			$finalResult = $this->product_swap($center, 4, $finalResult);
		else
			$finalResult = $this->product_swap($center, 1, $finalResult);
			
	}
	return array(      
	  '#theme' 	=> 'product_detail_page',
	  '#name' 	=> array('result'=>$finalResult,'page_title'=> $page_title,'page_desc'=>$page_desc,'count'=>$count,'center'=>$center,'is_mobile'=>$is_mobile),
	  
	  
    );  
  }
  public function all_product_details(){
	
	$pd_config 	= \Drupal::config('demo.settings')->get('pd_config');
	$page_title =  $pd_config['pd_title']; 
	$page_desc 	=  $pd_config['pd_desc']; 
	$finalResult = array();
	$sid = 'homepage_product';
	$entity_subqueue = \Drupal::entityManager()->getStorage('entity_subqueue')->load($sid);
	$items = $entity_subqueue->get('items')->getValue();
	foreach($items as $item) {
		$nodeids[] = $item['target_id'];
	}
	$nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeids);
	$i= 1;
	
	foreach($nodes as $node) {
	  $nid = $node->get('nid')->value;	
	  $product_image = $node->get('field_image')->entity->uri->value;
	  
	  if($product_image && $product_image != '')
			$finalResult[$i]['product_image'] 		= file_create_url($node->get('field_image')->entity->uri->value);
	  else{
		  
		  $finalResult[$i]['product_image'] = '';
	  }
	  $finalResult[$i]['title'] 				= $node->get('title')->value;
	  //$finalResult[$i]['product_image'] 		= file_create_url($node->get('field_image')->entity->uri->value);	  
	  $finalResult[$i]['product_short_desc'] 	= $node->get('field_product_short_desc')->value;
	  $finalResult[$i]['product_long_desc'] 	= $node->get('field_product_long_desc')->value;	  
	  $finalResult[$i]['product_video_url'] 	= $node->get('field_product_video_url')->value;
	  $finalResult[$i]['product_dyk'] 			= $node->get('field_product_section_desc')->value;
	  $finalResult[$i]['product_vowel'] 		= $this->product_vowel_chk($finalResult[$i]['title']);
	  $i++;
	}
	$count  = count($finalResult);
	$is_mobile = $this->isMobileDev();
	
	return array(      
	  '#theme' 	=> 'product_detail_page',
	  '#name' 	=> array('result'=>$finalResult,'page_title'=> $page_title,'page_desc'=>$page_desc,'count'=>$count,'center'=>$center,'is_mobile'=>$is_mobile),
	  
	  
    );  
  }
  public function isMobileDev(){
    if(isset($_SERVER['HTTP_USER_AGENT']) and !empty($_SERVER['HTTP_USER_AGENT'])){
       $user_ag = $_SERVER['HTTP_USER_AGENT'];
       if(preg_match('/(Mobile|Android|Tablet|GoBrowser|[0-9]x[0-9]*|uZardWeb\/|Mini|Doris\/|Skyfire\/|iPhone|Fennec\/|Maemo|Iris\/|CLDC\-|Mobi\/)/uis',$user_ag)){
          return true;
       }else{
          return false;
       };
    }else{
       return false;    
    };
}
  public function product_vowel_chk($title){
	 $first = $title[0];	 
	$vowelArr = array('A','E','I','O','U','a','e','i','o','u');
	if(in_array($first,$vowelArr))
		return 'an';
	else
		return 'a';
  }
	public function product_swap($key1, $key2, &$array) {
		$ary = array();
		$temp = array();
		
        $temp=$array[$key1];
		$array[$key1]=$array[$key2];
		$array[$key2]=$temp;
        return $array;
    }
	public function whyus_testimonials() {
		$whyus_config 	= \Drupal::config('demo.settings')->get('whyus_detail_config');		 
		$finalResult = array();		
		$query = \Drupal::entityTypeManager()->getStorage("node")->getQuery();
		$query->condition('type' ,'why_us_testimonials','=')
			  ->condition('status' ,1);
		$result = $query->execute();
		$nodes = \Drupal::entityTypeManager()->getStorage("node")->loadMultiple($result);
		$i= 1;
		$left = $right= 1;
		
		$leftImageHtml = '<ul id="testimonial1">';
		$leftArrHtml = '<ul id="testimonial2">';
		$rightArrHtml = '<ul id="testimonial3">';
		$rightImageHtml = '<ul id="testimonial4">';
		foreach($nodes as $k => $node) {
		  $nid = $node->get('nid')->value;		  
		  $imageUrl 	= file_create_url($node->get('field_author_image')->entity->uri->value);		  	  
		  if($i % 2 == 0){			
			$leftImageHtml .= '<li><div class="col">'.'<img src="'.$imageUrl.'" alt="" height="300" width="100%">'.'</div></li>';
			$leftArrHtml .= '<li><div class="col"><div class="overlay"></div><div class="testimonial-text"><span>"</span>'.wordwrap(html_entity_decode($node->get("body")->value),25,"<br>\n",TRUE).'<span class="text-right">"</span></div>'.'<img src="'.$imageUrl.'" alt="" height="300" width="100%">'.'</div></li>';
			$left++;
			
		  }else{			
			$rightImageHtml .= '<li><div class="col">'.'<img src="'.$imageUrl.'" alt="" height="300" width="100%">'.'</div></li>';
			$rightArrHtml .= '<li><div class="col"><div class="overlay"></div><div class="testimonial-text"><span>"</span>'.wordwrap(html_entity_decode($node->get("body")->value),25,"<br>\n",TRUE).'<span class="text-right">"</span></div>'.'<img src="'.$imageUrl.'" alt="" height="300" width="100%">'.'</div></li>';			
			$right++;
		  }
		  $i++;
		}
		$leftImageHtml .= '</ul>';
		$leftArrHtml .= '</ul>';
		$rightImageHtml .= '</ul>';		
		$rightArrHtml .= '</ul>';
		$response = new AjaxResponse();    
		$response->addCommand(new HtmlCommand('#left_testimonial', $leftImageHtml.$leftArrHtml));
		$response->addCommand(new HtmlCommand('#right_testimonial', $rightArrHtml.$rightImageHtml));
		
		//our process section
		$ourProcessHtml = '';		
		$sid = 'homepage_why_us';
		$queue_status = \Drupal::config('entityqueue.entity_queue.'.$sid)->get('status');
		$nodeids = array();
		if($queue_status) {
			$entity_subqueue = \Drupal::entityManager()->getStorage('entity_subqueue')->load($sid);
			$items = $entity_subqueue->get('items')->getValue();
			foreach($items as $item) {
				$nodeids[] = $item['target_id'];
			}
		}
		$results = array();
		if(!empty($nodeids)) {
			$nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeids);	
			foreach($nodes as $node) {
				if($node->get('status')->value == 1) {
					$imageurl 		= file_create_url($node->get('field_why_us_type_icon')->entity->uri->value);  
					$why_us_title 	= $node->get('title')->value;      	  
					$why_us_data	= $node->get('field_why_us_data')->value;
					$ourProcessHtml.= '<div class="col-md-4 padd40 text-center"><div class="col"><p>'.$why_us_title.'</p>';
					$ourProcessHtml.= '<img src="'.$imageurl.'"> <p class="font-lg">'.$why_us_data.'</p></div></div>';
				}		  
			}
		}
		$response->addCommand(new HtmlCommand('#our_process_ajax', $ourProcessHtml));
		//certificate
		$certificateHtml = '';
		$query = \Drupal::entityTypeManager()->getStorage("node")->getQuery();
		$query->condition('type' ,'why_us_certificates','=')
			  ->condition('status' ,1);
		$result = $query->execute();
		$nodes = \Drupal::entityTypeManager()->getStorage("node")->loadMultiple($result);		
		
		if(count($nodes)> 6){
			$certificateHtml.= '<ul class="bxslider">';
		}else{
			$certificateHtml.= '<ul class="awards">';
		}
		foreach($nodes as $node) {			
			
			$certificateIcon 	= file_create_url($node->get('field_why_us_type_icon')->entity->uri->value);
			$certificateHtml.= '<li class="text-center"><img src="'.$certificateIcon.'" alt="" height="160px" width="160px"></li>';
			
		}
		$certificateHtml.= '</ul>';
		$response->addCommand(new HtmlCommand('#certificate_ajax', $certificateHtml));
		return $response;
	}
	public function why_goodmortgage() {
		$alias = \Drupal::service('path.alias_manager')->getPathByAlias('/whyusdetail');

		$params = Url::fromUri("internal:" . $alias)->getRouteParameters();
		$entity_type = key($params);
		$node = \Drupal::entityTypeManager()->getStorage($entity_type)->load($params[$entity_type]);
		$body = $node->get('body')->value;
		$node_js = $node->get('field_node_js')->value;
		$node_css = $node->get('field_node_css')->value;
		/*
		$whyus_config 	= \Drupal::config('demo.settings')->get('whyus_detail_config');		 
		$finalResult = array();		
		$query = \Drupal::entityTypeManager()->getStorage("node")->getQuery();
		$query->condition('type' ,'why_us_testimonials','=')
			  ->condition('status' ,1);
		$result = $query->execute();
		$nodes = \Drupal::entityTypeManager()->getStorage("node")->loadMultiple($result);
		$i= 1;
		$left = $right= 1;
		$leftArrImage = $leftArrText = $rightArrImage = $rightArrText = array();
		foreach($nodes as $k => $node) {
		  $nid = $node->get('nid')->value;	
		  
		  $imageUrl 	= file_create_url($node->get('field_author_image')->entity->uri->value);
		  	  
		  if($i % 2 == 0){
			$leftArrText[$left]['id'] 		= $nid;
			$leftArrText[$left]['body'] 	= $node->get('body')->value;
			$leftArrText[$left]['image'] 	= $imageUrl;
			$leftArrImage[$left]['id'] 	= $nid;
			$leftArrImage[$left]['image'] 	= $imageUrl;
			$left++;
		  }else{
			$rightArrText[$right]['id'] 	= $nid;
			$rightArrText[$right]['body'] 	= $node->get('body')->value;
			$rightArrText[$right]['image'] 	= $imageUrl;
			$rightArrImage[$right]['id'] 	= $nid;
			$rightArrImage[$right]['image'] = $imageUrl; 
			$right++;
		  }
		  $i++;
		}
		//our process section
		$sid = 'homepage_why_us';
		$queue_status = \Drupal::config('entityqueue.entity_queue.'.$sid)->get('status');
		$nodeids = array();
		if($queue_status) {
			$entity_subqueue = \Drupal::entityManager()->getStorage('entity_subqueue')->load($sid);
			$items = $entity_subqueue->get('items')->getValue();
			foreach($items as $item) {
				$nodeids[] = $item['target_id'];
			}
		}
		$results = array();
		if(!empty($nodeids)) {
			$nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeids);	
			foreach($nodes as $node) {
				if($node->get('status')->value == 1) {
					$nid = $node->get('nid')->value;
					$results[$nid]['why_us_type_icon'] 	= file_create_url($node->get('field_why_us_type_icon')->entity->uri->value);  
					$results[$nid]['title'] 			= $node->get('title')->value;      	  
					$results[$nid]['why_us_data']		= $node->get('field_why_us_data')->value;
				}		  
			}
		}
		//certificate
		$query = \Drupal::entityTypeManager()->getStorage("node")->getQuery();
		$query->condition('type' ,'why_us_certificates','=')
			  ->condition('status' ,1);
		$result = $query->execute();
		$nodes = \Drupal::entityTypeManager()->getStorage("node")->loadMultiple($result);
		
		$certificateResults = array();
		$c = 0;
		foreach($nodes as $node) {			
			$nid = $node->get('nid')->value;
			$certificateResults[$c]['icon'] 	= file_create_url($node->get('field_why_us_type_icon')->entity->uri->value);
			$c++;
		}
		
		//end
		return array(      
		  '#theme' 	=> 'whyus_detail_page',
		  '#name' 	=> array('certificateResults'=>$certificateResults,'results'=>$results,'leftArrText'=>$leftArrText,'leftArrImage'=>$leftArrImage,'rightArrText'=>$rightArrText,'rightArrImage'=>$rightArrImage,'whyus_config'=>$whyus_config),
		 
		);  
		*/
		return array(      
		  '#theme' 	=> 'whyus_detail_page_new',
		  '#name' 	=> array('body'=>$body,'node_js'=>$node_js,'node_css'=>$node_css),
		 
		);
	}
}