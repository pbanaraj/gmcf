<?php
namespace Drupal\customise\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Quick Rate Controller.
 */
class QuickRateController extends ControllerBase {

  /**
   * Initializing the things here.
   */
  public function __construct() {
    global $base_url;
    $this->storage = \Drupal::entityTypeManager()->getStorage("node");
    $this->user_storage = \Drupal::entityTypeManager()->getStorage("user");
    $this->current_user = \Drupal::currentUser();
    $this->current_user_uid = \Drupal::currentUser()->id();
    $this->base_url = $base_url;
  }
  public function quick_rate_landing(){    

	$finalResult = array("0"=>array("label"=>"Rates","help_text"=>""),"1"=>array("label"=>"APR","help_text"=>""),"2"=>array("label"=>"Monthly Payment","help_text"=>"sample help text"),"3"=>array("label"=>"Points/Credits","help_text"=>"sample help text"),"4"=>array("label"=>"Fees","help_text"=>"sample help text"));		
	
	$loan_products = array("30 year fixed"=>"30 year fixed","20 year fixed"=>"20 year fixed","15 year fixed"=>"15 year fixed","10 year fixed"=>"10 year fixed","5/1 ARM"=>"5/1 ARM","3/1 ARM"=>"3/1 ARM","7/1 ARM"=>"7/1 ARM");
	$credit_scores = array("795"=>"Excellent-740 & Above","709"=>"Very Good- 680 to 739","639"=>"Good-600 to 679","559"=>"Fair- 520 to 599","259"=>"Average- 519 & Lower");
    $property_types = array("1"=>"Single Family","2"=>"Condo","4"=>"PUDs","5"=>"Multi-Unit","6"=>"Hi-Rise Condo ( greater than 4 floors)","8"=>"Townhome","10"=>"Manufactured","11"=>"Leasehold","12"=>"Detached Condo");
	$occupency_types = array("2"=>"Primary Home","3"=>"Second Home","0"=>"Investment Property");
	$settedadminrates = \Drupal::configFactory()->getEditable('demo.settings')->get("quickrates");
	//echo "<pre>";print_r($settedadminrates);
	$stuff = array("30 Year Fixed"=>array("0"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.265","APR"=>"3.215","MonthlyPayment"=>"1300","points"=>"2202","credit"=>"2","TotalFees"=>"1500"),"2"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.365","APR"=>"3.315","MonthlyPayment"=>"1400","points"=>"2200","credit"=>"2","TotalFees"=>"1600"),"3"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.465","APR"=>"3.415","MonthlyPayment"=>"1500","points"=>"2300","credit"=>"2","TotalFees"=>"1700"),"4"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.565","APR"=>"3.515","MonthlyPayment"=>"1600","points"=>"2100","credit"=>"2","TotalFees"=>"1800")),"20 Year Fixed"=>array("0"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.765","APR"=>"3.715","MonthlyPayment"=>"2100","points"=>"2204","credit"=>"2","TotalFees"=>"2150"),"2"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.865","APR"=>"3.815","MonthlyPayment"=>"1650","points"=>"2204","credit"=>"2","TotalFees"=>"1550"),"3"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.185","APR"=>"3.205","MonthlyPayment"=>"1950","points"=>"2110","credit"=>"2","TotalFees"=>"1650"),"4"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.965","APR"=>"3.915","MonthlyPayment"=>"2120","points"=>"2104","credit"=>"2","TotalFees"=>"2250")),"15 Year Fixed"=>array("0"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.444","APR"=>"3.227","MonthlyPayment"=>"1755","points"=>"2204","credit"=>"2","TotalFees"=>"1970"),"2"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.425","APR"=>"3.349","MonthlyPayment"=>"2750","points"=>"2204","credit"=>"2","TotalFees"=>"2190"),"3"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.306","APR"=>"3.409","MonthlyPayment"=>"1690","points"=>"2104","credit"=>"2","TotalFees"=>"1770"),"4"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.964","APR"=>"3.919","MonthlyPayment"=>"2800","points"=>"2204","credit"=>"2","TotalFees"=>"2900")),"10 Year Fixed"=>array("0"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.180","APR"=>"3.200","MonthlyPayment"=>"3150","points"=>"2204","credit"=>"2","TotalFees"=>"3170"),"2"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.295","APR"=>"3.299","MonthlyPayment"=>"2990","points"=>"2204","credit"=>"2","TotalFees"=>"3025"),"3"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.300","APR"=>"3.308","MonthlyPayment"=>"3145","points"=>"1904","credit"=>"2","TotalFees"=>"3165"),"4"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.402","APR"=>"3.504","MonthlyPayment"=>"3660","points"=>"2004","credit"=>"2","TotalFees"=>"3678")));
	$data = json_encode($stuff);
    $rates = json_decode($data,TRUE);
	$rates1 = array();
	foreach($rates as $key => $rate) {
		$newkey = str_replace(" ","_",$key);
		foreach($rate as $key1=>$rate1) {
			if (in_array($key1,$settedadminrates[$newkey]['rates']['key_row'])) {
				$rates1[$key][] = $rate1;
			}
		}
	}	
	$results = array();
	foreach($rates1 as $array) {
			foreach($array as $inner) {
				$results[] = $inner;
			}    
	}
	// sort data based on monthly payment
	$rates = array();
	$rates1 = array();$temp = array();$temp1 = array();$temp2 = array();
		
	foreach($results as $aEntry1) {
		if(!in_array($aEntry1['MonthlyPayment'],$temp)) {
			$temp1[] = $aEntry1;
			$temp[] = $aEntry1['MonthlyPayment'];
		} else {
			$temp2[] = $aEntry1;
		}
	}
				
	$val_temp = array();
	$val_temp = $temp1[0];
	unset($temp1[0]);
	array_push($temp1,$val_temp);
	if(count($temp2) > 0) {
		$result = array_merge($temp1,$temp2);
	} else {
		$result = $results;
	}
	foreach($result as $aEntry) {
		$rates[$aEntry['LenderProductName']][] = $aEntry;
	}		 
	$rates_new = array();
	foreach($rates as $key => $rate1) {			
		usort($rate1, function ($a, $b) {
			return strcmp($a["MonthlyPayment"],$b["MonthlyPayment"]);
		});
		$rates_new[$key] = $rate1;
	}
	
	return array(      
	  '#theme' 	=> 'quick_rate_landing',
	  '#name' 	=> array('result'=>$finalResult,'loan_products'=>$loan_products,'credit_scores'=>$credit_scores,'property_types'=>$property_types,'occupency_types'=>$occupency_types,'rates'=>$rates_new,'settedadminrates'=>$settedadminrates,'quick_rates'=>$results),
    );  
  }
  public function quick_rate_submit(Request $request) {  
		
		$form_info = $request->request->all();
		//echo "<pre>";print_r($form_info);die;
		if(isset($form_info['qrq_purchase_price'])) {
			$active_tab = "purchase";
		} else {
			$active_tab = "refinance";
		}
		/*
  		$ch = curl_init();            
        // set your site url
        curl_setopt($ch, CURLOPT_URL,"http://localhost:8080/getjsoninfo1.php");

        curl_setopt($ch, CURLOPT_POST, 1);
        // postvar1, postvar2 .. are the parameters to send with post
        curl_setopt($ch, CURLOPT_POSTFIELDS,
                    "postvar2=value2&postvar3=value3");          
        // receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $server_output = curl_exec ($ch);      
	
        curl_close ($ch);
		
		$rates = json_decode($server_output,TRUE);
		*/
		$finalResult = array("0"=>array("label"=>"Rates","help_text"=>""),"1"=>array("label"=>"APR","help_text"=>""),"2"=>array("label"=>"Monthly Payment","help_text"=>"sample help text"),"3"=>array("label"=>"Points/Credits","help_text"=>"sample help text"),"4"=>array("label"=>"Fees","help_text"=>"sample help text"));		

		$loan_products = array("30 year fixed"=>"30 year fixed","20 year fixed"=>"20 year fixed","15 year fixed"=>"15 year fixed","10 year fixed"=>"10 year fixed","5/1 ARM"=>"5/1 ARM","3/1 ARM"=>"3/1 ARM","7/1 ARM"=>"7/1 ARM");
		$credit_scores = array("795"=>"Excellent-740 & Above","709"=>"Very Good- 680 to 739","639"=>"Good-600 to 679","559"=>"Fair- 520 to 599","259"=>"Average- 519 & Lower");
		$property_types = array("1"=>"Single Family","2"=>"Condo","4"=>"PUDs","5"=>"Multi-Unit","6"=>"Hi-Rise Condo ( greater than 4 floors)","8"=>"Townhome","10"=>"Manufactured","11"=>"Leasehold","12"=>"Detached Condo");
		$occupency_types = array("2"=>"Primary Home","3"=>"Second Home","0"=>"Investment Property");
		$stuff = array("30 Year Fixed"=>array("0"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.265","APR"=>"3.215","MonthlyPayment"=>"1300","points"=>"2202","credit"=>"2","TotalFees"=>"1500"),"2"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.365","APR"=>"3.315","MonthlyPayment"=>"1400","points"=>"2200","credit"=>"2","TotalFees"=>"1600"),"3"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.465","APR"=>"3.415","MonthlyPayment"=>"1500","points"=>"2300","credit"=>"2","TotalFees"=>"1700"),"4"=>array("LenderProductName"=>"30 Year Fixed","Rate"=>"3.565","APR"=>"3.515","MonthlyPayment"=>"1600","points"=>"2100","credit"=>"2","TotalFees"=>"1800")),"20 Year Fixed"=>array("0"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.765","APR"=>"3.715","MonthlyPayment"=>"2100","points"=>"2204","credit"=>"2","TotalFees"=>"2150"),"2"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.865","APR"=>"3.815","MonthlyPayment"=>"1650","points"=>"2204","credit"=>"2","TotalFees"=>"1550"),"3"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.185","APR"=>"3.205","MonthlyPayment"=>"1950","points"=>"2110","credit"=>"2","TotalFees"=>"1650"),"4"=>array("LenderProductName"=>"20 Year Fixed","Rate"=>"3.965","APR"=>"3.915","MonthlyPayment"=>"2120","points"=>"2104","credit"=>"2","TotalFees"=>"2250")),"15 Year Fixed"=>array("0"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.444","APR"=>"3.227","MonthlyPayment"=>"1755","points"=>"2204","credit"=>"2","TotalFees"=>"1970"),"2"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.425","APR"=>"3.349","MonthlyPayment"=>"2750","points"=>"2204","credit"=>"2","TotalFees"=>"2190"),"3"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.306","APR"=>"3.409","MonthlyPayment"=>"1690","points"=>"2104","credit"=>"2","TotalFees"=>"1770"),"4"=>array("LenderProductName"=>"15 Year Fixed","Rate"=>"3.964","APR"=>"3.919","MonthlyPayment"=>"2800","points"=>"2204","credit"=>"2","TotalFees"=>"2900")),"10 Year Fixed"=>array("0"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.165","APR"=>"3.115","MonthlyPayment"=>"1200","points"=>"2200","credit"=>"2","TotalFees"=>"1400"),"1"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.180","APR"=>"3.200","MonthlyPayment"=>"3150","points"=>"2204","credit"=>"2","TotalFees"=>"3170"),"2"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.295","APR"=>"3.299","MonthlyPayment"=>"2990","points"=>"2204","credit"=>"2","TotalFees"=>"3025"),"3"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.300","APR"=>"3.308","MonthlyPayment"=>"3145","points"=>"1904","credit"=>"2","TotalFees"=>"3165"),"4"=>array("LenderProductName"=>"10 Year Fixed","Rate"=>"3.402","APR"=>"3.504","MonthlyPayment"=>"3660","points"=>"2004","credit"=>"2","TotalFees"=>"3678")));
		$data = json_encode($stuff);
		$rates = json_decode($data,TRUE);
		$results = array();

		foreach($rates as $array) {
			foreach($array as $inner) {
				$results[] = $inner;
			}    
		}
		// sort data based on monthly payment
		$rates = array();
		$rates1 = array();$temp = array();$temp1 = array();$temp2 = array();
		
		foreach($results as $aEntry1) {
			if(!in_array($aEntry1['MonthlyPayment'],$temp)) {
				$temp1[] = $aEntry1;
				$temp[] = $aEntry1['MonthlyPayment'];
			} else {
				$temp2[] = $aEntry1;
			}
		}
				
		$val_temp = array();
		$val_temp = $temp1[0];
		unset($temp1[0]);
		array_push($temp1,$val_temp);
		if(count($temp2) > 0) {
			$result = array_merge($temp1,$temp2);
		} else {
			$result = $results;
		}
		foreach($result as $aEntry) {
			$rates[$aEntry['LenderProductName']][] = $aEntry;
		}		 
		$rates_new = array();
		foreach($rates as $key => $rate1) {			
			usort($rate1, function ($a, $b) {
				return strcmp($a["MonthlyPayment"],$b["MonthlyPayment"]);
			});
			$rates_new[$key] = $rate1;
		}
		
		return array(      
		  '#theme' 	=> 'quick_rate_landing_submit',
		  '#name' 	=> array('result'=>$finalResult,'loan_products'=>$loan_products,'credit_scores'=>$credit_scores,'property_types'=>$property_types,'occupency_types'=>$occupency_types,'rates'=>$rates_new,'form_info'=>$form_info,'quick_rates'=>$results,'active_tab'=>$active_tab),
		);      
  
  }
  public function quick_rate_sort() { 
  
		$finalResult = array("0"=>array("label"=>"Rates","help_text"=>""),"1"=>array("label"=>"APR","help_text"=>""),"2"=>array("label"=>"Monthly Payment","help_text"=>"sample help text"),"3"=>array("label"=>"Points/Credits","help_text"=>"sample help text"),"4"=>array("label"=>"Fees","help_text"=>"sample help text"));		
		$result = $_POST['rates'];
		$type_sort = $_POST['type_sort'];
		$rates = array();
		$rates1 = array();$temp = array();$temp1 = array();$temp2 = array();
		switch($type_sort) {
			case "LMP":
				foreach($result as $aEntry1) {
					if(!in_array($aEntry1['MonthlyPayment'],$temp)) {
						$temp1[] = $aEntry1;
						$temp[] = $aEntry1['MonthlyPayment'];
					} else {
						$temp2[] = $aEntry1;
					}
				}
				break;
			case "LR":
				foreach($result as $aEntry1) {
					if(!in_array($aEntry1['Rate'],$temp)) {
						$temp1[] = $aEntry1;
						$temp[] = $aEntry1['Rate'];
					} else {
						$temp2[] = $aEntry1;
					}
				}
				break;
			case "LF":
				foreach($result as $aEntry1) {
					if(!in_array($aEntry1['TotalFees'],$temp)) {
						$temp1[] = $aEntry1;
						$temp[] = $aEntry1['TotalFees'];
					} else {
						$temp2[] = $aEntry1;
					}
				}
				break;
		}
		$val_temp = array();
		$val_temp = $temp1[0];
		unset($temp1[0]);
		array_push($temp1,$val_temp);
		if(count($temp2) > 0) {
			$result = array_merge($temp1,$temp2);
		} else {
			$result = $result;
		}
		foreach($result as $aEntry) {
			$rates[$aEntry['LenderProductName']][] = $aEntry;
		}		 
		$rates_new = array();
		foreach($rates as $key => $rate1) {
			switch($type_sort) {
				case "LMP":
						usort($rate1, function ($a, $b) {
							return strcmp($a["MonthlyPayment"],$b["MonthlyPayment"]);
						});
						$rates_new[$key] = $rate1;
						break;
				case "LR":
						usort($rate1, function ($a, $b) {
							return strcmp($a["Rate"],$b["Rate"]);
						});
						$rates_new[$key] = $rate1;
						break;
				case "LF":
						usort($rate1, function ($a, $b) {
							return strcmp($a["TotalFees"],$b["TotalFees"]);
						});
						$rates_new[$key] = $rate1;
						break;
			}
			
		}
		$i = 0;
		$html_data = "";
		foreach($rates_new as $key => $rate) {
			$newkey = str_replace(" ","_",$key);
			if($i == 0) {
				$openclass = "open";
				$openactive = "openactive";
			} else {
				$openclass = "";
				$openactive = "";
			}
			
			$html_data .='<div class="accordion-head '.$openclass.'"><h4>'.$key.'</h4><span class="active-header"> </span><span class="active-text">OUR TOP PICK</span><div class="arrow down"></div></div><div class="accordion-body '.$openactive.'"><div class="table-responsive"><table class="table"><thead><tr>';
			foreach($finalResult as $key => $val_qrq) {
				$html_data .= '<th>'.$val_qrq["label"].'&nbsp;';
				if (!empty($val_qrq['help_text'])) {
					$html_data .= '<a href="#" data-toggle="tooltip" data-placement="top" title="'.$val_qrq["help_text"].'"><i class="fa fa-info-circle" aria-hidden="true"></i></a>';
				}
				$html_data .= '</th>';
			}
			$html_data .='<th></th></tr></thead><tbody>';
			foreach($rate as $key1=>$rate1) {
				$html_data .= '<tr><td>$'.$rate1["Rate"].'%</td><td>$'.$rate1["APR"].'%</td><td>$'.$rate1["MonthlyPayment"].'</td><td>$'.$rate1["points"].'<span class="small-txt">@'.$rate1["credit"].' points</span></td><td>$'.$rate1["TotalFees"].'</td><td class="text-center"><a class="select-rate" href="javascript:void(0)">Select Rate</a></td></tr>';										
			}
			$html_data .= '</tbody></table></div></div>';
			$i++;
		}
		
		echo $html_data;exit;
  }
  public function testimonial_info() {  
	$query = \Drupal::entityTypeManager()->getStorage("node")->getQuery();
    $query->condition('type' ,'testimonials','=')
              ->condition('status' ,1);
    $result = $query->execute();
    $nodes = \Drupal::entityTypeManager()->getStorage("node")->loadMultiple($result);
    foreach($nodes as $node) {
            $nid = $node->get('nid')->value;	  
            $finalResult[$nid]['body'] = $node->get('body')->value;
            $finalResult[$nid]['customer_name'] = $node->get('field_customer_name')->value;
            $finalResult[$nid]['customer_since'] = $node->get('field_customer_since')->value;
    }
	$testimonial_html = "";
	foreach($finalResult as $key => $testimonial) {
		$testimonial_html .= '<li><div class="col-sm-8">'.$testimonial['body'].'</div><div class="col-sm-4"> - '.$testimonial['customer_name'].',<br> Customer since '.$testimonial['customer_since'].'</div></li>';                                                
    }
	echo $testimonial_html;exit;	
  }
  public function products_info() {
            $sid = 'homepage_product';	
            $queue_status = \Drupal::config('entityqueue.entity_queue.'.$sid)->get('status');
            $nodeids = array();
            if($queue_status) {
                    $entity_subqueue = \Drupal::entityManager()->getStorage('entity_subqueue')->load($sid);
                    $items = $entity_subqueue->get('items')->getValue();
                    foreach($items as $item) {
                            $nodeids[] = $item['target_id'];
                    }
            }
			//echo "<pre>";print_r($nodeids);die;

            $finalResult = array();
            if(!empty($nodeids)) {
                    $nodes = \Drupal::entityTypeManager()->getStorage('node')->loadMultiple($nodeids);	
                    foreach($nodes as $node) {
                      if($node->get('status')->value == 1) {
                              $nid = $node->get('nid')->value;	 
                              $finalResult[$nid]['nid'] = $nid;  
                              $finalResult[$nid]['title'] = $node->get('title')->value;      	  
                              $finalResult[$nid]['product_short_desc'] = $node->get('field_product_short_desc')->value;
                              $finalResult[$nid]['product_url'] = $base_url."/products/".$nid;
                              $finalResult[$nid]['product_video_url'] = $node->get('field_product_video_url')->value;
                     }		  
                    }
            }
			//echo "<pre>";print_r($finalResult);die;
			$prod_html = "";
			foreach($finalResult as $key => $prod) {
				$prod_url = $prod["product_url"];
				$onclick = "location.href='".$prod_url."'";
				$prod_html .= '<li><div class="col-item"><div class="header text-center">'.$prod["title"].'</div>'.$prod["product_short_desc"].'<div class="text-center footer"><button class="btn btn-info custom-btn" onclick="'.$onclick.'">Details</button></div></div></li>';
			}
			echo $prod_html;exit;
  }
 
}