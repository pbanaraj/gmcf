<?php

/**
 * @file
 * Contains \Drupal\customise\Plugin\Block\logoBlock.
 */

namespace Drupal\customise\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'logoBlock' block.
 *
 * @Block(
 *  id = "logo_block",
 *  admin_label = @Translation("Logo block"),
 * )
 */
class logoBlock extends BlockBase {


  /**
   * {@inheritdoc}
   */
  public function build() {
    //$build = [];
    //$build['logo_block']['#markup'] = 'Implement logoBlock.';
    
    $block_data ="";
	global $base_url;
	$this->base_url = $base_url;
    return array(
        '#theme' => 'logo_block', 
        '#block_data' => array('base_url'=>$this->base_url), 
     );

    //return $build;
  }

}
