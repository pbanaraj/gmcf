<?php

/**
 * @file
 * Contains \Drupal\customise\Plugin\Block\headerRightBlock.
 */

namespace Drupal\customise\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'headerRightBlock' block.
 *
 * @Block(
 *  id = "header_right_block",
 *  admin_label = @Translation("Header right block"),
 * )
 */
class headerRightBlock extends BlockBase {


  /**
   * {@inheritdoc}
   */
  public function build() {
    $block_data ="";
    
    $block = \Drupal\block_content\Entity\BlockContent::load(1);
    $ph_number = \Drupal::entityManager()->getViewBuilder('block_content')->view($block);
    
    //$block = \Drupal\block_content\Entity\BlockContent::load('basis_search');
   //$search = \Drupal::entityManager()->getViewBuilder('block_content')->view($block);
    $block = \Drupal\block\Entity\Block::load('searchform');
    $search = \Drupal::entityManager()
      ->getViewBuilder('block')
      ->view($block);
    //return $render;

    return array(
        '#theme' => 'header_right_block', 
        '#block_data' => $block_data, 
        '#ph_number' => $ph_number,
        '#search' => $search,
     );
  }
}
