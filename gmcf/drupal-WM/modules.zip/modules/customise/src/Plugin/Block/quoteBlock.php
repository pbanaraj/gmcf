<?php

/**
 * @file
 * Contains \Drupal\customise\Plugin\Block\quoteBlock.
 */

namespace Drupal\customise\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'quoteBlock' block.
 *
 * @Block(
 *  id = "quote_block",
 *  admin_label = @Translation("Quote block"),
 * )
 */
class quoteBlock extends BlockBase {


  /**
   * {@inheritdoc}
   */
  public function build() {
    $block_data ="";
	$loan_products = array("30 year fixed"=>"30 year fixed","20 year fixed"=>"20 year fixed","15 year fixed"=>"15 year fixed","10 year fixed"=>"10 year fixed","5/1 ARM"=>"5/1 ARM","3/1 ARM"=>"3/1 ARM","7/1 ARM"=>"7/1 ARM");
	$credit_scores = array("795"=>"Excellent-740 & Above","709"=>"Very Good- 680 to 739","639"=>"Good-600 to 679","559"=>"Fair- 520 to 599","259"=>"Average- 519 & Lower");
	$property_types = array("2"=>"Condo","4"=>"PUDs","5"=>"Multi-Unit","6"=>"Hi-Rise Condo ( greater than 4 floors)","8"=>"Townhome","10"=>"Manufactured","11"=>"Leasehold","12"=>"Detached Condo");
	$occupency_types = array("2"=>"Primary Home","3"=>"Second Home","0"=>"Investment Property");

    return array(
        '#theme' => 'quick_rate_quote_block', 
        '#block_data' => array('loan_products'=>$loan_products,'credit_scores'=>$credit_scores,'property_types'=>$property_types,'occupency_types'=>$occupency_types), 
     );
  }

}
