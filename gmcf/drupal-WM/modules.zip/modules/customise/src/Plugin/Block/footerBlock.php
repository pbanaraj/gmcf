<?php

/**
 * @file
 * Contains \Drupal\customise\Plugin\Block\footerBlock.
 */

namespace Drupal\customise\Plugin\Block;

use Drupal\Core\Block\BlockBase;

/**
 * Provides a 'footerBlock' block.
 *
 * @Block(
 *  id = "footer_block",
 *  admin_label = @Translation("Footer block"),
 * )
 */
class footerBlock extends BlockBase {


  /**
   * {@inheritdoc}
   */
  public function build() {
    $block_data ="";

    return array(
        '#theme' => 'footer_block', 
        '#block_data' => $block_data, 
     );
  }

}
