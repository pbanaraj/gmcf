INTRODUCTION
------------
This module enables the Font Size and Family plugin from CKEditor.com in your
WYSIWYG.This plugin adds Font Size and Font Family dropdowns that apply as
inline element style. The default collection of fonts includes most popular
serif fonts (Times New Roman, Georgia), sans-serif fonts (Arial, Verdana,
Tahoma), and monospaced fonts (Courier New).

The list of font styles can be easily customized

INSTALLATION
------------
1. Download the plugin from http://ckeditor.com/addon/loremipsum.
2. Place the plugin in the root libraries folder (/libraries).
3. Enable CKEditor Font in the Drupal admin.
4. Configure your WYSIWYG toolbar to include the buttons.

REQUIREMENTS
------------
CKEditor Module (Core)
