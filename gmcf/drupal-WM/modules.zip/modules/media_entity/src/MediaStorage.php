<?php

namespace Drupal\media_entity;

use Drupal\Core\Entity\Sql\SqlContentEntityStorage;

/**
 * Media storage class.
 */
class MediaStorage extends SqlContentEntityStorage implements MediaStorageInterface {

}
