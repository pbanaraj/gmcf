(function ($, Drupal,drupalSettings) {   
   'use strict';
   $(document).on('click','.removeContribute',function(e){
     e.preventDefault();
     var redirectlink = $(this).attr('href');
	 if(confirm(" Are you sure you want to delete contribute?")){
		window.location.href=redirectlink;
	 } else {
		return false;
	 }
   });
   $(document).on('click','a.remove_section',function(e){
     e.preventDefault();
     var redirectlink = $(this).attr('href');
	 var sectionkey = $(this).data('key');
	 if(confirm(" Are you sure you want to delete section?")){
		window.location.href=redirectlink+"?key="+sectionkey;
	 } else {
		return false;
	 }
   });
   $(document).on('click','.validate_rates',function(e){
	 $('input[name="' + this.name + '"]').not(this).prop('checked', false);
	 if($('.validate_rates:checked').length > 3) {
		alert("Maximum you can select 3 rates..");return false;
	 }	 
	 var resName = $(this).data('key')+"[key_row]";	 
     $('input[name="' + resName + '"]').val($(this).data('key1'));	 
   });
   $(document).bind('cbox_closed', function () {
	$('#cboxOverlay').remove();
	$('#colorbox').remove();
	});
})(jQuery, Drupal,drupalSettings);
