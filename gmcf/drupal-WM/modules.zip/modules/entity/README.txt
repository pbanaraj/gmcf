Entity API module
-----------------

This module contains improvements and extensions to the Drupal 8 Entity system.
The goal is to bring useful improvements to upcoming Drupal 8 minor releases
(e.g. 8.1, 8.2, ..) while maintaining backwards compatibility in future Entity
API module versions (based on the improvements which went into core).

@todo: Explain version compatibility pattern.
@todo: Add overview of all items and maintainers.

